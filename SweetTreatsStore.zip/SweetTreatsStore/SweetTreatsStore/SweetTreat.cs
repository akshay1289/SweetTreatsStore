﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SweetTreatsStore
{
    public class SweetTreat
    {
        public List<DeliveryPerson> deliveryBoys { set; get; }

        public SweetTreat()
        {
            deliveryBoys = new List<DeliveryPerson>()
            {
                new DeliveryPerson() { Name = "Bobby", WorkTimeFrom = 9f, WorkTimeTo = 13f, IsHavingRefrigerator = true, MaxDistanceTravel = 5f, PerMileCost = 1.75f },
                new DeliveryPerson() { Name = "Martin", WorkTimeFrom = 9f, WorkTimeTo = 17f, IsHavingRefrigerator = false, MaxDistanceTravel = 3f, PerMileCost = 1.50f },
                new DeliveryPerson() { Name = "Geoff", WorkTimeFrom = 10f, WorkTimeTo = 16f, IsHavingRefrigerator = true, MaxDistanceTravel = 4f, PerMileCost = 2.00f }
            };
        }

        public DeliveryPerson GetDelieryOption(string time,float distance,bool refrigeratorReq)
        {
            float time24, timeAdd = 0;
            time = time.Replace(":", ".");
            if (time.ToLower().Contains("pm"))
                timeAdd = 12;
            float.TryParse(time.ToLower().Replace("am", "").Replace("pm", ""), out time24);
            time24 = time24 + timeAdd;
            var elgDeliveryBoys = deliveryBoys.Where(x => time24 >= x.WorkTimeFrom && time24 <= x.WorkTimeTo).ToList();
            if (!elgDeliveryBoys.Any())
                throw new Exception("Suitable delivery option not available.");

            elgDeliveryBoys = elgDeliveryBoys.Where(x => x.IsHavingRefrigerator == refrigeratorReq).ToList();
            if (!elgDeliveryBoys.Any())
                throw new Exception("Suitable delivery option not available.");

            elgDeliveryBoys = elgDeliveryBoys.Where(x => distance <= x.MaxDistanceTravel).ToList();
            if (!elgDeliveryBoys.Any())
                throw new Exception("Suitable delivery option not available.");

            var deliveryOption = elgDeliveryBoys.Select(x => new { DeliveryBoy = x, Price = x.PerMileCost * distance })
                                .OrderBy(y => y.Price).FirstOrDefault();
            if(deliveryOption == null)
                throw new Exception("Suitable delivery option not available.");

            return deliveryOption.DeliveryBoy;
        }
    }
}
