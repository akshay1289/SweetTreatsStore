﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SweetTreatsStore
{
    public class DeliveryPerson
    {
        public string Name { set; get; }
        public float WorkTimeFrom { set; get; }
        public float WorkTimeTo { set; get; }
        public float MaxDistanceTravel { set; get; }
        public bool IsHavingRefrigerator { set; get; }
        public float PerMileCost { set; get; }
    }
}
