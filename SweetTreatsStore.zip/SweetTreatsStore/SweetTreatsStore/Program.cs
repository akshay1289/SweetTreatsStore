﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SweetTreatsStore
{
    class Program
    {
        List<DeliveryPerson> deliveryBoys;
        static void Main(string[] args)
        {
            string time;
            float distance;
            bool isRefrigeratorReq;
            try
            {
                Console.WriteLine("Enter delivery time with(am/pm):");
                time = Console.ReadLine();

                Console.WriteLine("Enter distance to travel:");
                distance = float.Parse(Console.ReadLine());

                Console.WriteLine("Is refrigerator required(y/n):");
                char ch = Console.ReadKey().KeyChar;

                if (ch == 'Y' || ch == 'y')
                    isRefrigeratorReq = true;
                else if (ch == 'N' || ch == 'n')
                    isRefrigeratorReq = false;
                else
                    throw new Exception("Invalid Refrigerator required input.");

                SweetTreat sweetTreat = new SweetTreat();
                DeliveryPerson deliveryBoy = sweetTreat.GetDelieryOption(time, distance, isRefrigeratorReq);
                Console.WriteLine($"\nAvailable delivery boy : {deliveryBoy.Name}");

            }
            catch (Exception ex)
            {
                Console.WriteLine("\n" + ex.Message);
            }
            Console.ReadLine();
        }
    }
}
